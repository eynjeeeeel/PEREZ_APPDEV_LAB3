<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */
$routes->get('/', 'Home::index');
$routes->get('/login', 'AdminController::login');
$routes->get('/register', 'AdminController::register');
$routes->post('/authreg', 'AdminController::authreg');
$routes->post('/authlogin', 'AdminController::authlogin');
$routes->get('/admintable','AdminController::gotoadmintable');
$routes->post('/createaccount','AdminController::createaccount');
$routes->get('/home', 'UserController::home');
