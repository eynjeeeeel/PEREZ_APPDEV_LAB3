<!DOCTYPE html>
<html lang="en">
    <?= view('ecommerce/header');?>
<body>
    <?= view('ecommerce/body');?>
    <?= view('ecommerce/footer');?>
</body>
</html>