<!DOCTYPE html>
<html lang="en">
<?=  view('admin/adlogin/adheader');?>
<body>
<?=  view('admin/adlogin/adbody');?>
</body>
</html>