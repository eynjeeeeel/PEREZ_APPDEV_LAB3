<!DOCTYPE html>
<html lang="en">
<?=  view('admin/adregister/regheader');?>
<body>
<?=  view('admin/adregister/regbody');?>
</body>
</html>